<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori Aset</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?> 
</head>

<body class="bg-gray-100">

    <!-- Header -->
    <header class=" navbar p-4 flex justify-between items-center">
        <div class="flex items-center">
            <img src="<?php echo e(asset('http://127.0.0.1:8000/images/logo-pln.png')); ?>" alt="Logo" class="h-18 w-12 mr-2">
            <h1 class="text-xl font-bold ">
                <a href="<?php echo e(route('dashboard')); ?>">Dashboard </a>
            </h1>
            <nav class="flex space-x-4">
                <a href="<?php echo e(route('kategori')); ?>" class=" font-bold ">Kategori Aset</a>
                <a href="<?php echo e(route('riwayat')); ?>" class=" font-bold ">Riwayat</a>
            </nav>
        </div>
        <div class="flex items-center relative group">
            <span class="mr-4  font-bold">Hello, <?php echo e(Auth::user()->name); ?></span>
            <button class=" font-bold focus:outline-none">
                Menu
            </button>
            <!-- Dropdown Menu -->
            <div class="absolute right-0 mt-2 w-48 bg-black rounded-md shadow-lg z-10 hidden group-hover:block">
                <a href="#" class="block px-4 py-2  "
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container mx-auto mt-4 p-4">
        <h2 class="text-2xl font-bold mr-4 mb-2">Kategori Aset</h2>

        <!-- Pesan Sukses atau Kesalahan -->
        <?php if(session('success')): ?>
        <div class="mb-4 text-green-500">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="mb-4 text-red-500">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Button untuk membuka modal -->
        <button onclick="openModal()" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">Tambah Kategori</button>

        <!-- PopUp Modal untuk tambah kategori -->
        <div id="addCategoryModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 z-50 hidden">
            <div class="flex items-center justify-center h-full">
                <div class="bg-white rounded-lg shadow-lg p-6 w-11/12 md:w-1/3">
                    <h2 class="text-xl font-bold mb-4">Tambah Kategori</h2>
                    <div id="error-message" class="text-red-500 text-center mb-4 hidden">Data tidak boleh kosong</div>

                    <form method="POST" action="<?php echo e(route('kategori.store')); ?>" enctype="multipart/form-data" onsubmit="return validateForm()">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <label for="name" class="block text-gray-700">Nama Kategori (maksimal 255 karakter)</label>
                            <input type="text" name="name" id="name" maxlength="255" class="w-full px-4 py-2 border rounded-lg" placeholder="Masukkan nama Kategori">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-4">
                            <label for="icon" class="block text-gray-700">Ikon Kategori (JPEG/JPG/PNG, maksimal 2MB)</label>
                            <input type="file" name="icon" id="icon" accept="image/*" class="w-full px-4 py-2 border rounded-lg">
                            <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Tambah Kategori</button>
                        <button type="button" class="bg-red-500 text-white px-4 py-2 rounded-lg" onclick="closeModal()">Batal</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Daftar Kategori -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow p-4 text-center hover:shadow-lg transition relative">
                <!-- Menambahkan elemen untuk menampilkan ikon -->
                <img src="<?php echo e(asset('storage/' . $category->icon)); ?>" alt="<?php echo e($category->name); ?> Icon" class="h-16 w-16 mx-auto mb-2">

                <h3 class="text-lg font-bold">
                    <a href="<?php echo e(route('category.show', ['category' => $category->name])); ?>" class="text-blue-500 hover:underline"><?php echo e($category->name); ?></a>
                </h3>

                <form method="POST" action="<?php echo e(route('kategori.destroy', $category->name)); ?>" class="absolute top-2 right-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="text-red-500 hover:text-red-600">Hapus</button>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Script untuk membuka dan menutup modal -->
    <script>
        function validateForm() {
            // Mengambil nilai dari input nama barang dan gambar
            const name = document.getElementById('name').value.trim();
            const imageInput = document.getElementById('icon');
            const errorMessage = document.getElementById('error-message');

            // Validasi: Pastikan nama barang tidak kosong
            if (!name) {
                errorMessage.textContent = "Nama barang tidak boleh kosong.";
                errorMessage.classList.remove('hidden');
                return false;
            }

            // Validasi ukuran file dan format gambar jika ada gambar yang diunggah
            if (imageInput.files.length > 0) {
                const file = imageInput.files[0];
                const fileSizeMB = file.size / 1024 / 1024; // Convert ukuran ke MB
                const fileExtension = file.name.split('.').pop().toLowerCase();

                // Cek ukuran file
                if (fileSizeMB > 2) {
                    errorMessage.textContent = "Ukuran gambar tidak boleh lebih dari 2MB.";
                    errorMessage.classList.remove('hidden');
                    return false;
                }

                // Cek format file
                if (fileExtension !== 'jpg' && fileExtension !== 'jpeg' && fileExtension !== 'png') {
                    errorMessage.textContent = "Format gambar harus JPG atau JPEG atau PNG.";
                    errorMessage.classList.remove('hidden');
                    return false;
                }
            } else {
                errorMessage.textContent = "Gambar aset tidak boleh kosong.";
                errorMessage.classList.remove('hidden');
                return false;
            }

            // Jika semua validasi lolos, sembunyikan pesan error dan lanjutkan submit
            errorMessage.classList.add('hidden');
            return true;
        }


        // Menampilkan modal
        function openModal() {
            document.getElementById('addCategoryModal').classList.remove('hidden');
        }

        // Menutup modal
        function closeModal() {
            document.getElementById('addCategoryModal').classList.add('hidden');
        }
    </script>

</body>

</html><?php /**PATH D:\Projectt\STIManagementAssets\resources\views/kategori.blade.php ENDPATH**/ ?>
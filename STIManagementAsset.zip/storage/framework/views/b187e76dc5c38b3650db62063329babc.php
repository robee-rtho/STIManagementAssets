<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Aset</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet">


</head>

<body class="bg-gray-100">

    <!-- Header -->
    <header class=" navbar p-4 flex justify-between items-center">
        <div class="flex items-center">
            <img src="<?php echo e(asset('http://127.0.0.1:8000/images/logo-pln.png')); ?>" alt="Logo" class="h-18 w-12 mr-2">
            <h1 class="text-xl font-bold ">
                <a href="<?php echo e(route('dashboard')); ?>">Dashboard </a>
            </h1>
            <nav class="flex space-x-4">
                <a href="<?php echo e(route('kategori')); ?>" class=" font-bold ">Kategori Aset</a>
                <a href="<?php echo e(route('riwayat')); ?>" class=" font-bold ">Riwayat</a>
            </nav>
        </div>
        <div class="flex items-center relative group">
            <span class="mr-4  font-bold">Hello, <?php echo e(Auth::user()->name); ?></span>
            <button class=" font-bold focus:outline-none">
                Menu
            </button>
            <!-- Dropdown Menu -->
            <div class="absolute right-0 mt-2 w-48 bg-black rounded-md shadow-lg z-10 hidden group-hover:block">
                <a href="#" class="block px-4 py-2  "
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </header>

    <!-- Main Content -->

    <div class="container mx-auto mt-4 p-4">
        <h2 class="text-xl font-bold mb-4">Riwayat Penambahan Aset</h2>
        <div id='recipients' class="p-8 mt-6 lg:mt-0 rounded shadow bg-white">


            <table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                <thead>
                    <tr>
                        <th data-priority="1">No</th>
                        <th data-priority="2">ID Aset</th>
                        <th data-priority="3">Nama Barang</th>
                        <th data-priority="4">Kategori Aset</th>
                        <th data-priority="5">Tanggal</th>
                        <th data-priority="6">Nama Admin</th>
                        <th data-priority="7">Keterangan</th>
                        <th data-priority="8">Aksi</th>


                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td data-priority="1"><?php echo e($loop->iteration); ?></td>
                        <td data-priority="2"><?php echo e($riwayat->asset->id_aset); ?></td>
                        <td data-priority="3"><?php echo e($riwayat->asset->name); ?></td>
                        <td data-priority="4"><?php echo e($riwayat->asset->category); ?></td>
                        <td data-priority="5"><?php echo e($riwayat->tanggal); ?></td>
                        <td data-priority="6"><?php echo e($riwayat->admin); ?></td>
                        <td data-priority="7"><?php echo e($riwayat->keterangan); ?></td>
                        <td data-priority="8">
                            <form action="<?php echo e(route('riwayat.destroy', $riwayat->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus riwayat ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>


        </div>

    </div>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

    <!--Datatables -->
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script>
        $(document).ready(function() {

            var table = $('#example').DataTable({
                    responsive: true
                })
                .columns.adjust()
                .responsive.recalc();
        });
    </script>
</body>

</html><?php /**PATH D:\Projectt\STIManagementAssets\resources\views/riwayat.blade.php ENDPATH**/ ?>